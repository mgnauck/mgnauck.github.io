
#include "Vertex.h"

Vertex::Vertex( Vector const& _pos ) : pos( _pos ), nrm( Vector( 0.0f, 0.0f, 0.0f ) ) {
}