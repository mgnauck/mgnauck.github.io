
#ifndef __ANIMATION_H__
#define __ANIMATION_H__

struct Animation {
	int		start;
	int		end;
	int		fps;
	int		frameCount;
	float	delta;
};

#endif